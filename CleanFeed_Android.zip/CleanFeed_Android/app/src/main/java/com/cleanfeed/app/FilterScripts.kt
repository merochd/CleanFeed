package com.cleanfeed.app

object FilterScripts {

    fun buildYoutubeScript(hideShorts: Boolean, grayscale: Boolean): String {
        return """
            (function() {
                const HIDE_SHORTS = $hideShorts;
                const GRAYSCALE = $grayscale;

                function applyStyles() {
                    let style = document.getElementById('cleanfeed-yt-style');
                    if (!style) {
                        style = document.createElement('style');
                        style.id = 'cleanfeed-yt-style';
                        document.head.appendChild(style);
                    }
                    let css = '';
                    if (GRAYSCALE) {
                        css += 'html { filter: grayscale(100%) !important; } ';
                    }
                    if (HIDE_SHORTS) {
                        css += `
                            ytm-reel-shelf-renderer,
                            ytd-reel-shelf-renderer,
                            ytm-shorts-lockup-view-model,
                            ytm-shorts-lockup-view-model-v2,
                            a[href^="/shorts"],
                            a[href*="/shorts/"] {
                                display: none !important;
                            }
                        `;
                    }
                    style.textContent = css;
                }

                function stripShortsNodes() {
                    if (!HIDE_SHORTS) return;

                    if (window.location.pathname.startsWith('/shorts')) {
                        window.location.replace('https://m.youtube.com/');
                        return;
                    }

                    document.querySelectorAll('ytm-pivot-bar-item-renderer').forEach(tab => {
                        const text = (tab.innerText || '').trim().toLowerCase();
                        if (text === 'shorts' || tab.querySelector('a[href*="/shorts"]')) {
                            tab.style.display = 'none';
                        }
                    });

                    document.querySelectorAll('a[href*="/shorts/"]').forEach(link => {
                        const card = link.closest(
                            'ytm-video-with-context-renderer, ytm-rich-item-renderer, ytm-compact-video-renderer, ytd-rich-item-renderer, ytd-video-renderer, ytm-reel-shelf-renderer'
                        );
                        if (card) card.style.display = 'none';
                    });

                    document.querySelectorAll('ytm-chip-cloud-chip-renderer, yt-chip-cloud-chip-renderer').forEach(chip => {
                        if ((chip.innerText || '').trim().toLowerCase() === 'shorts') {
                            chip.style.display = 'none';
                        }
                    });
                }

                applyStyles();
                stripShortsNodes();

                if (!window.__cleanfeedYtObserver) {
                    window.__cleanfeedYtObserver = new MutationObserver(() => {
                        stripShortsNodes();
                    });
                    window.__cleanfeedYtObserver.observe(document.documentElement, {
                        childList: true,
                        subtree: true
                    });
                }
            })();
        """.trimIndent()
    }

    fun buildInstagramScript(hideReels: Boolean, hideExplore: Boolean, grayscale: Boolean): String {
        return """
            (function() {
                const HIDE_REELS = $hideReels;
                const HIDE_EXPLORE = $hideExplore;
                const GRAYSCALE = $grayscale;

                function applyStyles() {
                    let style = document.getElementById('cleanfeed-ig-style');
                    if (!style) {
                        style = document.createElement('style');
                        style.id = 'cleanfeed-ig-style';
                        document.head.appendChild(style);
                    }
                    let css = '';
                    if (GRAYSCALE) {
                        css += 'html { filter: grayscale(100%) !important; } ';
                    }
                    if (HIDE_REELS) {
                        css += `
                            a[href*="/reels"],
                            a[href^="/reels/"] {
                                display: none !important;
                            }
                        `;
                    }
                    if (HIDE_EXPLORE) {
                        css += `
                            a[href="/explore/"],
                            a[href^="/explore"] {
                                display: none !important;
                            }
                        `;
                    }
                    style.textContent = css;
                }

                function stripReelsNodes() {
                    if (HIDE_REELS && (window.location.pathname.startsWith('/reels') || window.location.pathname.startsWith('/reel/'))) {
                        window.location.replace('https://www.instagram.com/');
                        return;
                    }
                    if (HIDE_EXPLORE && window.location.pathname.startsWith('/explore')) {
                        window.location.replace('https://www.instagram.com/');
                        return;
                    }

                    if (!HIDE_REELS) return;

                    document.querySelectorAll('svg[aria-label="Reels"], svg[aria-label="Reels icon"]').forEach(svg => {
                        const navItem = svg.closest('a, div[role="button"]');
                        if (navItem) navItem.style.display = 'none';
                    });

                    document.querySelectorAll('a[href*="/reel/"]').forEach(link => {
                        const article = link.closest('article');
                        if (article) {
                            article.style.display = 'none';
                        } else {
                            const tile = link.closest('div[style*="flex"], div._aabd, div._ac7v');
                            if (tile) tile.style.display = 'none';
                            else link.style.display = 'none';
                        }
                    });
                }

                applyStyles();
                stripReelsNodes();

                if (!window.__cleanfeedIgObserver) {
                    window.__cleanfeedIgObserver = new MutationObserver(() => {
                        stripReelsNodes();
                    });
                    window.__cleanfeedIgObserver.observe(document.documentElement, {
                        childList: true,
                        subtree: true
                    });
                }
            })();
        """.trimIndent()
    }
}
