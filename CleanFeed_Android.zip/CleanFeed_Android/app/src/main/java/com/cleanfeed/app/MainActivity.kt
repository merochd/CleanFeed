package com.cleanfeed.app

import android.annotation.SuppressLint
import android.content.Context
import android.os.Bundle
import android.view.View
import android.webkit.CookieManager
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.ScrollView
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.switchmaterial.SwitchMaterial

class MainActivity : AppCompatActivity() {

    private lateinit var webYoutube: WebView
    private lateinit var webInstagram: WebView
    private lateinit var filtersPanel: ScrollView
    private lateinit var bottomNav: BottomNavigationView

    private var activeTab = R.id.nav_youtube

    private val prefs by lazy { getSharedPreferences("cleanfeed_prefs", Context.MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        webYoutube = findViewById(R.id.webViewYoutube)
        webInstagram = findViewById(R.id.webViewInstagram)
        filtersPanel = findViewById(R.id.filtersPanel)
        bottomNav = findViewById(R.id.bottomNav)

        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(webYoutube, true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(webInstagram, true)

        setupYoutubeWebView()
        setupInstagramWebView()
        setupFiltersPanel()
        setupBottomNav()
        setupBackNavigation()

        webYoutube.loadUrl("https://m.youtube.com/")
        webInstagram.loadUrl("https://www.instagram.com/")
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun configureCommonSettings(webView: WebView) {
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            mediaPlaybackRequiresUserGesture = false
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            useWideViewPort = true
            loadWithOverviewMode = true
        }
    }

    private fun setupYoutubeWebView() {
        configureCommonSettings(webYoutube)
        webYoutube.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val url = request?.url?.toString() ?: return false
                if (isHideShortsEnabled() && url.contains("/shorts")) {
                    view?.loadUrl("https://m.youtube.com/")
                    return true
                }
                return false
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                injectYoutubeFilters()
            }

            override fun doUpdateVisitedHistory(view: WebView?, url: String?, isReload: Boolean) {
                super.doUpdateVisitedHistory(view, url, isReload)
                injectYoutubeFilters()
            }
        }
    }

    private fun setupInstagramWebView() {
        configureCommonSettings(webInstagram)
        webInstagram.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val url = request?.url?.toString() ?: return false
                if (isHideReelsEnabled() && (url.contains("/reels") || url.contains("/reel/"))) {
                    view?.loadUrl("https://www.instagram.com/")
                    return true
                }
                if (isHideExploreEnabled() && url.contains("/explore")) {
                    view?.loadUrl("https://www.instagram.com/")
                    return true
                }
                return false
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                injectInstagramFilters()
            }

            override fun doUpdateVisitedHistory(view: WebView?, url: String?, isReload: Boolean) {
                super.doUpdateVisitedHistory(view, url, isReload)
                injectInstagramFilters()
            }
        }
    }

    private fun injectYoutubeFilters() {
        val js = FilterScripts.buildYoutubeScript(
            hideShorts = isHideShortsEnabled(),
            grayscale = isGrayscaleEnabled()
        )
        webYoutube.evaluateJavascript(js, null)
    }

    private fun injectInstagramFilters() {
        val js = FilterScripts.buildInstagramScript(
            hideReels = isHideReelsEnabled(),
            hideExplore = isHideExploreEnabled(),
            grayscale = isGrayscaleEnabled()
        )
        webInstagram.evaluateJavascript(js, null)
    }

    private fun setupFiltersPanel() {
        val switchShorts = findViewById<SwitchMaterial>(R.id.switchHideShorts)
        val switchReels = findViewById<SwitchMaterial>(R.id.switchHideReels)
        val switchExplore = findViewById<SwitchMaterial>(R.id.switchHideExplore)
        val switchGray = findViewById<SwitchMaterial>(R.id.switchGrayscale)
        val btnReload = findViewById<Button>(R.id.btnReloadAll)

        switchShorts.isChecked = isHideShortsEnabled()
        switchReels.isChecked = isHideReelsEnabled()
        switchExplore.isChecked = isHideExploreEnabled()
        switchGray.isChecked = isGrayscaleEnabled()

        switchShorts.setOnCheckedChangeListener { _, checked ->
            prefs.edit().putBoolean("hide_shorts", checked).apply()
        }
        switchReels.setOnCheckedChangeListener { _, checked ->
            prefs.edit().putBoolean("hide_reels", checked).apply()
        }
        switchExplore.setOnCheckedChangeListener { _, checked ->
            prefs.edit().putBoolean("hide_explore", checked).apply()
        }
        switchGray.setOnCheckedChangeListener { _, checked ->
            prefs.edit().putBoolean("grayscale", checked).apply()
        }

        btnReload.setOnClickListener {
            webYoutube.reload()
            webInstagram.reload()
            bottomNav.selectedItemId = R.id.nav_youtube
        }
    }

    private fun setupBottomNav() {
        bottomNav.setOnItemSelectedListener { item ->
            activeTab = item.itemId
            webYoutube.visibility = if (item.itemId == R.id.nav_youtube) View.VISIBLE else View.GONE
            webInstagram.visibility = if (item.itemId == R.id.nav_instagram) View.VISIBLE else View.GONE
            filtersPanel.visibility = if (item.itemId == R.id.nav_filters) View.VISIBLE else View.GONE
            true
        }
    }

    private fun setupBackNavigation() {
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                when (activeTab) {
                    R.id.nav_youtube -> if (webYoutube.canGoBack()) webYoutube.goBack() else finish()
                    R.id.nav_instagram -> if (webInstagram.canGoBack()) webInstagram.goBack() else finish()
                    else -> bottomNav.selectedItemId = R.id.nav_youtube
                }
            }
        })
    }

    private fun isHideShortsEnabled() = prefs.getBoolean("hide_shorts", true)
    private fun isHideReelsEnabled() = prefs.getBoolean("hide_reels", true)
    private fun isHideExploreEnabled() = prefs.getBoolean("hide_explore", false)
    private fun isGrayscaleEnabled() = prefs.getBoolean("grayscale", false)
}
