# CleanFeed (Android)

A standalone, 100% local Android WebView app for YouTube and Instagram that removes Shorts and Reels before you ever see them—zero servers, zero subscriptions.

## Option 1: Build the APK on Your Phone (No PC Needed, via GitHub Actions)
1. Extract this zip on your phone.
2. Create a free private repository on GitHub in your mobile browser.
3. Upload the contents of `CleanFeed_Android/` (including the hidden `.github/workflows/build-apk.yml` file).
4. Open the **Actions** tab in your repo—GitHub will automatically run **Build CleanFeed APK** (~2 minutes).
5. Download the `CleanFeed-debug-apk` artifact, extract `app-debug.apk`, and tap it to install on Android.

## Option 2: Build on PC with Android Studio
1. Extract this folder and open it in **Android Studio** (**File > Open**).
2. Connect your Android phone via USB (with USB Debugging enabled) and click **Run** (or **Build > Build APK(s)**).
